// ========================================================================
// SỔ NAM TÀO - HỆ THỐNG TRA CỨU VAI VẾ VÀ LỜI CHÚC TỰ ĐỘNG
// ========================================================================

// ------------------------------------------------------------------------
// PHẦN 1: DANH BẠ (NAME MAPPING)
// ------------------------------------------------------------------------
export const NAME_TO_ROLE_MAPPING: Record<string, string> = {
  // Ví dụ của bạn:
  "lê hoàng ân": "chú", 
  "nguyễn thị kim thoa": "thím",
  
  // Gia đình
  "lê hoàng hải": "bố",
  "cao thị cung": "mẹ",
  "lê thị ngọc trầm": "chị", 
  "lê thị ngọc thơm": "chị",
  "lê thị ngọc hoa": "chị",
  "lê thị ngọc thắm": "anh", 
  
  "đỗ thị như quỳnh": "người yêu",
  "hồ chí kiệt": "mẹ", 
  "nguyễn lê hoàng anh tuấn": "chú",
};

// ------------------------------------------------------------------------
// PHẦN 2: KHO ẢNH NỀN
// ------------------------------------------------------------------------
export const WISH_BACKGROUNDS = [
    "https://images.unsplash.com/photo-1548625361-1b2cb81938d2?q=80&w=1920", // Hoa mai vàng
    "https://images.unsplash.com/photo-1516075276335-514d7920718d?q=80&w=1920", // Lồng đèn đỏ
    "https://images.unsplash.com/photo-1610214227038-897728f395ee?q=80&w=1920", // Trừu tượng đỏ nghệ thuật
    "https://images.unsplash.com/photo-1514416432279-50fac261ea7f?q=80&w=1920", // Ánh sáng mờ ảo (Bokeh)
    "https://images.unsplash.com/photo-1546552356-3fae876a61ca?q=80&w=1920"  // Vàng Gold sang trọng
];

// ------------------------------------------------------------------------
// PHẦN 3: KHO LỜI CHÚC THEO VAI VẾ (ROLE LIBRARY)
// ------------------------------------------------------------------------
export const ROLE_BASED_WISHES: Record<string, { text: string; theme: 'gold' | 'red' | 'pink' | 'cyan' }[]> = {
  
  // ============================
  // NHÓM ÔNG BÀ
  // ============================
  "ông": [
    { text: "Con kính chúc Ông năm mới Xuân Bính Ngọ phúc như Đông Hải, thọ tỷ Nam Sơn.", theme: "red" },
    { text: "Năm mới tết đến, con kính chúc Ông sức khỏe dẻo dai, tinh thần minh mẫn, vui vầy cùng con cháu.", theme: "gold" },
    { text: "Chúc Ông năm nay thân tâm an lạc, vạn sự cát tường, nụ cười luôn nở trên môi.", theme: "gold" },
    { text: "Kính chúc Ông một năm mới an khang thịnh vượng, cây dẻo dai, đời trường thọ.", theme: "red" },
    { text: "Đầu xuân năm mới, con mong Ông luôn mạnh khỏe, là cây cao bóng cả che chở cho cả gia đình.", theme: "gold" }
  ],
  "bà": [
    { text: "Con kính chúc Bà năm mới bách niên giai lão, sống vui sống khỏe bên con cháu.", theme: "red" },
    { text: "Chúc Bà của con năm nay chân khỏe, mắt sáng, tâm an nhàn hưởng phúc lộc trời ban.", theme: "pink" },
    { text: "Năm mới con chỉ mong Bà luôn mạnh khỏe, ăn ngon ngủ yên, nụ cười hiền hậu mãi rạng rỡ.", theme: "gold" },
    { text: "Kính chúc Bà sống lâu trăm tuổi, phúc lộc đầy nhà, con cháu hiếu thảo.", theme: "red" },
    { text: "Xuân sang kính chúc Bà yêu quý vạn sự như ý, tỷ sự như mơ, sức khỏe dồi dào.", theme: "pink" }
  ],

  // ============================
  // NHÓM BỐ MẸ
  // ============================
  "bố": [
    { text: "Chúc Bố năm 2026 sức khỏe vô biên, công việc thuận lợi, vạn sự hanh thông.", theme: "gold" },
    { text: "Bố là trụ cột vững chắc của gia đình. Năm mới con chúc Bố luôn vững tay chèo lái, gặt hái nhiều thành công.", theme: "cyan" },
    { text: "Mong Bố năm nay có nhiều thời gian nghỉ ngơi, đi du lịch, tận hưởng niềm vui cuộc sống.", theme: "red" },
    { text: "Chúc Bố năm mới phong độ ngời ngời, tâm trí thảnh thơi, tiền tài tấn tới.", theme: "gold" },
    { text: "Cảm ơn Bố đã luôn hy sinh vì chúng con. Chúc Bố một năm mới tràn đầy sức khỏe và hạnh phúc.", theme: "gold" }
  ],
  "mẹ": [
    { text: "Chúc Mẹ yêu năm mới mãi trẻ đẹp, nụ cười luôn rạng rỡ như hoa xuân ngày Tết.", theme: "pink" },
    { text: "Cảm ơn Mẹ đã vất vả vì chúng con. Năm nay Mẹ hãy dành nhiều thời gian chăm sóc bản thân và tận hưởng niềm vui nhé.", theme: "red" },
    { text: "Chúc Mẹ sức khỏe dồi dào, tâm hồn phơi phới, tài lộc đầy nhà.", theme: "gold" },
    { text: "Mẹ là mùa xuân của cả nhà. Chúc Mẹ năm mới thật nhiều niềm vui, bình an và hạnh phúc.", theme: "pink" },
    { text: "Chúc Mẹ năm Bính Ngọ vạn sự cát tường, nét đẹp mặn mà theo thời gian.", theme: "red" }
  ],

  // ============================
  // NHÓM CÔ, DÌ, CHÚ, BÁC, THÍM
  // ============================
  "bác": [
    { text: "Cháu chúc Bác năm mới tài lộc thăng hoa, gia đạo hưng thịnh, vạn sự viên mãn.", theme: "gold" },
    { text: "Chúc Bác năm Bính Ngọ sức khỏe dồi dào, vui vầy bên con cháu, phúc lộc đầy nhà.", theme: "red" },
    { text: "Năm mới kính chúc Bác an nhàn hưởng phúc, tiền tài dư dả, mọi sự hanh thông.", theme: "gold" },
    { text: "Chúc Bác và đại gia đình năm mới vạn sự cát tường, tỷ sự như mơ, giàu sang phú quý.", theme: "cyan" },
    { text: "Kính chúc Bác luôn mạnh khỏe, là cây cao bóng cả, chỗ dựa tinh thần vững chắc cho con cháu.", theme: "gold" }
  ],
  "chú": [
    { text: "Chúc Chú năm mới làm ăn phát đạt, tiền vào như nước, gia đình sung túc.", theme: "gold" },
    { text: "Năm mới chúc Chú sức khỏe bền bỉ, công danh thăng tiến, tài lộc đầy kho.", theme: "cyan" },
    { text: "Chúc Chú năm Bính Ngọ vạn sự hanh thông, con cháu ngoan hiền, gia đạo an vui.", theme: "red" },
    { text: "Năm mới chúc Chú mã đáo thành công, sự nghiệp rực rỡ, hưởng trọn vinh hoa.", theme: "gold" },
    { text: "Chúc Chú luôn phong độ, lạc quan, dẫn dắt gia đình gặt hái nhiều thành công lớn.", theme: "cyan" }
  ],
  "cô": [
    { text: "Chúc Cô năm mới tài lộc vượng phát, gia đạo bình an, hưởng phước cùng con cháu.", theme: "pink" },
    { text: "Kính chúc Cô năm nay tiền tài rủng rỉnh, sức khỏe dồi dào, cuộc sống viên mãn.", theme: "gold" },
    { text: "Năm mới chúc Cô vạn sự như ý, con cháu hiếu thảo, luôn vui vẻ yêu đời.", theme: "red" },
    { text: "Chúc Cô luôn rạng rỡ, an nhàn hưởng lộc, gia đình hạnh phúc sum vầy.", theme: "pink" },
    { text: "Năm Bính Ngọ, chúc Cô gặt hái nhiều tài lộc, mọi điều tốt đẹp nhất sẽ đến với gia đình.", theme: "gold" }
  ],
  "thím": [
    { text: "Chúc Thím năm mới tài lộc thăng hoa, tiền vào như nước, gia đạo hưng thịnh.", theme: "gold" },
    { text: "Kính chúc Thím sức khỏe dồi dào, an nhàn hưởng phúc bên con cháu thảo hiền.", theme: "pink" },
    { text: "Năm mới chúc Thím vạn sự hanh thông, buôn bán (nếu có) đắt hàng, tiền tài dư dả.", theme: "red" },
    { text: "Chúc Thím luôn vui vẻ, hạnh phúc viên mãn, năm nay nhà mình có thêm nhiều tin vui.", theme: "pink" },
    { text: "Xuân Bính Ngọ, chúc Thím vạn sự cát tường, phú quý đầy nhà, đời sống vương giả.", theme: "gold" }
  ],
  "dì": [
    { text: "Chúc Dì năm mới tài lộc dồi dào, cuộc sống thăng hoa, vạn sự như ý.", theme: "pink" },
    { text: "Kính chúc Dì sức khỏe dẻo dai, vui vẻ bên con cháu, tiền bạc rủng rỉnh.", theme: "cyan" },
    { text: "Năm mới chúc Dì an khang thịnh vượng, gia đình êm ấm, phúc lộc đầy nhà.", theme: "gold" },
    { text: "Mong Dì một năm mới bình an, hưởng trọn niềm vui tuổi trung niên viên mãn.", theme: "pink" },
    { text: "Chúc Dì luôn tươi trẻ, yêu đời, là chỗ dựa tinh thần ấm áp cho cả gia đình.", theme: "red" }
  ],
  "cậu": [
    { text: "Chúc Cậu năm mới mã đáo thành công, sự nghiệp vững vàng, tài lộc tấn tới.", theme: "gold" },
    { text: "Chúc Cậu sức khỏe vô đối, tinh thần lạc quan, gia đình thịnh vượng.", theme: "cyan" },
    { text: "Năm mới chúc Cậu tài lộc đầy nhà, con cháu sum vầy, vạn sự an khang.", theme: "gold" },
    { text: "Chúc Cậu năm Bính Ngọ công danh thăng tiến, cuộc sống sung túc đủ đầy.", theme: "red" },
    { text: "Kính chúc Cậu một năm đại thắng, tiền vào như nước sông Đà, tiền ra nhỏ giọt.", theme: "cyan" }
  ],
  "mợ": [
    { text: "Chúc Mợ năm nay tài lộc song hành, gia đình êm ấm, hưởng phúc trời ban.", theme: "pink" },
    { text: "Chúc Mợ sức khỏe dồi dào, tâm hồn thư thái, vui vầy cùng cháu con.", theme: "gold" },
    { text: "Năm mới chúc Mợ vạn sự như ý, hạnh phúc viên mãn, phú quý vinh hoa.", theme: "red" },
    { text: "Chúc Mợ luôn rạng rỡ, quý phái, gia đạo an khang, lộc lá quanh năm.", theme: "pink" },
    { text: "Kính chúc Mợ một năm mới an khang thịnh vượng, tiền vàng đầy két.", theme: "gold" }
  ],

  // ============================
  // NHÓM ANH CHỊ EM (ĐÃ CẬP NHẬT: Ưu tiên Tài Lộc, Gia Đạo, Bỏ tình duyên/trẻ trung)
  // ============================
  "anh": [
    { text: "Chúc Anh năm mới tài lộc hanh thông, gia đạo bình an, vạn sự hưng thịnh.", theme: "gold" },
    { text: "Năm mới kính chúc Anh công danh thăng tiến, tiền vào như nước, gia đình sung túc.", theme: "cyan" },
    { text: "Chúc Anh năm Bính Ngọ mã đáo thành công, sự nghiệp vững vàng, hưởng trọn vinh hoa.", theme: "red" },
    { text: "Chúc Anh sức khỏe dồi dào, là trụ cột vững chắc cho gia đình, con cháu ngoan hiền.", theme: "gold" },
    { text: "Kính chúc Anh một năm đại thắng, đắc tài đắc lộc, phú quý đầy nhà.", theme: "cyan" }
  ],
  "chị": [
    { text: "Chúc Chị năm mới tài lộc vượng phát, gia đình êm ấm, con cháu thảo hiền.", theme: "pink" },
    { text: "Năm mới chúc Chị an nhàn hưởng phúc, sức khỏe dồi dào, vạn sự như ý.", theme: "gold" },
    { text: "Chúc Chị năm Bính Ngọ tiền tài dư dả, cuộc sống viên mãn, phú quý vinh hoa.", theme: "cyan" },
    { text: "Mong Chị một năm mới bình an, gia đạo hưng thịnh, gặt hái nhiều thành công.", theme: "pink" },
    { text: "Kính chúc Chị năm mới tấn tài tấn lộc, mọi điều tốt đẹp nhất sẽ đến với gia đình.", theme: "red" }
  ],
  "em": [
    { text: "Chúc Em năm mới học hành tấn tới, thi cử đỗ đạt, làm rạng danh gia đình.", theme: "cyan" },
    { text: "Chúc Em hay ăn chóng lớn, ngoan ngoãn, nghe lời bố mẹ và luôn vui vẻ.", theme: "pink" },
    { text: "Năm mới chúc Em gặp nhiều may mắn, nhận nhiều lì xì, luôn là niềm tự hào của cả nhà.", theme: "gold" },
    { text: "Mong Em năm nay trưởng thành hơn, tự tin hơn và đạt được mọi ước mơ của mình.", theme: "cyan" },
    { text: "Chúc Em một năm mới tràn đầy năng lượng, sức khỏe dồi dào và nhiều trải nghiệm thú vị.", theme: "red" }
  ],

  // ============================
  // NHÓM VỢ CHỒNG / NGƯỜI YÊU
  // ============================
  "vợ": [
    { text: "Năm mới chúc Vợ yêu luôn xinh đẹp, dịu dàng và là hậu phương vững chắc của bố con anh.", theme: "pink" },
    { text: "Cảm ơn em đã vất vả vì gia đình. Năm nay anh sẽ cố gắng nhiều hơn để em được vui vẻ, hạnh phúc.", theme: "red" },
    { text: "Chúc Vợ sức khỏe dồi dào, tâm hồn phơi phới, mọi điều tốt đẹp nhất sẽ đến với em.", theme: "gold" },
    { text: "Em là mùa xuân vĩnh cửu của anh. Chúc em năm mới luôn rạng rỡ và ngập tràn yêu thương.", theme: "pink" },
    { text: "Chúc Vợ năm nay công việc thuận lợi, ít lo toan, nhiều niềm vui và luôn được anh yêu chiều.", theme: "gold" }
  ],
  "chồng": [
    { text: "Chúc Chồng yêu năm mới công danh sự nghiệp rạng rỡ, là chỗ dựa vững chắc cho mẹ con em.", theme: "cyan" },
    { text: "Năm nay chúc Chồng sức khỏe dồi dào, đi đâu cũng được quý nhân phù trợ, về nhà có vợ yêu thương.", theme: "red" },
    { text: "Chúc trụ cột gia đình năm Bính Ngọ vững vàng tay lái, mang nhiều tài lộc và niềm vui về nhà.", theme: "gold" },
    { text: "Mong Chồng năm mới bớt âu lo, thêm nhiều tiếng cười và luôn hạnh phúc bên gia đình nhỏ.", theme: "cyan" },
    { text: "Chúc Chồng yêu vạn sự như ý, tỷ sự như mơ, tình cảm vợ chồng mình mãi mặn nồng.", theme: "pink" }
  ],
  "người yêu": [
    { text: "Năm mới chúc người yêu của anh/em luôn xinh đẹp/phong độ, hạnh phúc và gặp nhiều may mắn.", theme: "pink" },
    { text: "Mong rằng năm 2026 sẽ là một năm tuyệt vời để chúng ta cùng nhau viết tiếp câu chuyện tình yêu đẹp.", theme: "cyan" },
    { text: "Chúc em/anh một năm mới tràn ngập niềm vui, công việc thuận lợi và luôn nhớ về nhau.", theme: "gold" },
    { text: "Năm mới đến rồi, chúc cho tình yêu của chúng mình ngày càng bền chặt và sớm về chung một nhà.", theme: "red" },
    { text: "Cảm ơn em/anh đã đến bên đời. Chúc nửa kia của tôi năm mới bình an, thành công và hạnh phúc.", theme: "pink" }
  ],

  // ============================
  // NHÓM XÃ HỘI
  // ============================
  "sếp": [
    { text: "Chúc Sếp năm mới chèo lái con thuyền doanh nghiệp vươn ra biển lớn, gặt hái thành công vang dội.", theme: "gold" },
    { text: "Kính chúc Sếp sức khỏe dồi dào, trí tuệ minh mẫn để tiếp tục dẫn dắt anh em đến những đỉnh cao mới.", theme: "red" },
    { text: "Năm Bính Ngọ chúc Sếp mã đáo thành công, vạn sự như ý, gia đạo an khang thịnh vượng.", theme: "gold" },
    { text: "Chúc Sếp một năm mới đắc tài đắc lộc, đắc nhân tâm, sự nghiệp thăng hoa rực rỡ.", theme: "cyan" },
    { text: "Mong Sếp năm nay có thêm nhiều bước tiến đột phá, đưa công ty phát triển bền vững.", theme: "gold" }
  ],
  "bạn": [
    { text: "Chúc bạn hiền năm mới tiền tài dư dả, sức khỏe dồi dào, tình duyên phơi phới.", theme: "cyan" },
    { text: "Năm mới chúc bạn sớm tìm được ý trung nhân, công việc thuận lợi, đời vui như tết.", theme: "pink" },
    { text: "Chúc bạn năm nay đổi vận hanh thông, mua nhà tậu xe, du lịch thả ga.", theme: "gold" },
    { text: "Mong bạn một năm mới bình an, hạnh phúc, mọi dự định đều thành công tốt đẹp.", theme: "red" },
    { text: "Chúc tình bạn của chúng ta mãi bền chặt. Năm mới chúc bạn và gia đình vạn sự cát tường.", theme: "cyan" }
  ],
  "đồng nghiệp": [
    { text: "Chúc đồng nghiệp năm mới KPI đạt đỉnh, công việc trôi chảy, tiền thưởng ngập tràn.", theme: "gold" },
    { text: "Năm mới vui vẻ, hợp tác thành công, cùng nhau đưa team mình đi lên nhé.", theme: "cyan" },
    { text: "Chúc bạn năm mới sức khỏe dẻo dai, tinh thần thoải mái, sự nghiệp thăng tiến.", theme: "gold" },
    { text: "Mong bạn một năm làm việc hiệu quả, gặt hái nhiều thành tích tốt và luôn vui vẻ.", theme: "pink" },
    { text: "Chúc đồng chí năm Bính Ngọ vạn sự hanh thông, gia đình hạnh phúc, an khang thịnh vượng.", theme: "red" }
  ]
};